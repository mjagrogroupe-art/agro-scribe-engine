import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

/**
 * CampaignManager page for managing marketing campaigns.
 * This page provides a placeholder layout with a heading and description.
 * Future development can add forms and lists to create and manage campaigns.
 */
const CampaignManager = () => {
  return (
    <AppLayout
      breadcrumbs={[
        { label: 'Dashboard', href: '/dashboard' },
        { label: 'Campaigns' },
      ]}
      title="Campaign Manager"
    >
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Create Campaign</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Use this page to create and manage marketing campaigns. You can
              define campaign names, select products, choose channels, and set
              schedules. This section is a placeholder and will be expanded
              with forms and lists in future iterations.
            </p>
            <div className="mt-4">
              <Button disabled>Create Campaign (Coming Soon)</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default CampaignManager;